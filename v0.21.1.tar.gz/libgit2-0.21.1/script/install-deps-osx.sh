#!/bin/sh

set -x

brew install libssh2 cmake
